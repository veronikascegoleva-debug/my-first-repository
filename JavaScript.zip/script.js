


let slaidaIndekss = 0;

function raditSlaidu(n) {
    let slaidi = document.getElementsByClassName("slaids");
    let punkti = document.getElementsByClassName("punkts");
    
    if (slaidi.length === 0) return;

    for (let i = 0; i < slaidi.length; i++) {
        slaidi[i].style.display = "none";
        slaidi[i].classList.remove("aktivs");
    }
    for (let i = 0; i < punkti.length; i++) {
        punkti[i].classList.remove("aktivs");
    }

    slaidaIndekss = n;
    if (n >= slaidi.length) { slaidaIndekss = 0; }
    if (n < 0) { slaidaIndekss = slaidi.length - 1; }

    slaidi[slaidaIndekss].style.display = "block";
    slaidi[slaidaIndekss].classList.add("aktivs");
    
    if (punkti.length > 0) {
        punkti[slaidaIndekss].classList.add("aktivs");
    }
}

function mainitSlaidu(n) {
    raditSlaidu(slaidaIndekss + n);
}

function ietUzSlaidu(n) {
    raditSlaidu(n);
}

window.onload = function() {
    raditSlaidu(0);
};













